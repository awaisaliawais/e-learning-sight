<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>bidmarketing - Online Earning Platform</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600&family=Nunito:wght@600;700;800&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <!-- Spinner Start -->
    <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>
    <!-- Spinner End -->


    <!-- Navbar Start -->
    <nav class="navbar navbar-expand-lg bg-light navbar-light shadow sticky-top p-0">
        <a href="index.php" class="navbar-brand d-flex align-items-center px-4 px-lg-5">
            <img src="img/logoo.png" alt="" class="me-3 h-100 w-100" style="filter: invert(100%);">
        </a>
        <button type="button" class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
            <div class="navbar-nav ms-auto p-4 p-lg-0">
                <a href="index.php" class="nav-item nav-link">Home</a>
                <a href="about.php" class="nav-item nav-link active">About Us</a>
                <a href="team.php" class="nav-item nav-link">Our Team</a>
                <a href="services.php" class="nav-item nav-link">Services</a>
                <a href="contact.php" class="nav-item nav-link">Contact Us</a>
                <a href="login.php" class="nav-item nav-link">Login</a>
                <a href="register.php" class="nav-item nav-link">Register</a>
            </div>
            <a href="register.php" class="btn btn-primary py-4 px-lg-5 d-none d-lg-block">Join Now<i class="fa fa-arrow-right ms-3"></i></a>
        </div>
    </nav>
    <!-- Navbar End -->


    <!-- Header Start -->
    <div class="container-fluid bg-primary py-5 mb-5 page-header">
        <div class="container py-5">
            <div class="row justify-content-center">
                <div class="col-sm-10 col-lg-8 text-center">
                    <h1 class="display-4 text-white animated slideInDown">About Us</h1>
                    <h5 class="text-white fs-4 animated slideInDown">Welcome to Bid Marketing</h5>
                    <p class="fs-6 text-white mb-4 pb-2">A leading platform dedicated to connecting talented individuals with exciting job opportunities.</p>
                    <!-- <a href="" class="btn btn-primary py-md-3 px-md-5 me-3 animated slideInLeft">GET STARTED</a> -->
                    <!-- <a href="" class="btn btn-light py-md-3 px-md-5 animated slideInRight">Join Now</a> -->
                </div>
            </div>
        </div>
    </div>
    <!-- Header End -->


    <!-- Service Start -->
    <div class="container-xxl py-5">
        <div class="container">
            <div class="row g-4">
                <div class="col-lg-4 col-sm-6 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="service-item pt-3 h-100">
                        <div class="p-4">
                            <i class="bi bi-pencil-square fa-3x text-primary mb-4"></i>
                            <h5 class="mb-3 fs-4">Our Mission</h5>
                            <p class="text-dark">In the era of Digital Global World we want to make Pakistani youngster worlds number one freelancer online earner.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-sm-6 wow fadeInUp" data-wow-delay="0.3s">
                    <div class="service-item pt-3 h-100">
                        <div class="p-4">
                            <i class="bi bi-file-earmark-medical-fill fa-3x text-primary mb-4"></i>
                            <h5 class="mb-3 fs-4">Our Vision</h5>
                            <p class="text-dark">In first phase we will train 1,00,000 youngster and teach them skills related to online work. Then to our high skilled workers/trainee we will provide online work as per skills from our regular internaional clients.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-sm-6 wow fadeInUp" data-wow-delay="0.5s">
                    <div class="service-item pt-3 h-100">
                        <div class="p-4">
                            <i class="bi bi-keyboard fa-3x text-primary mb-4"></i>
                            <h5 class="mb-3 fs-4">Why Us</h5>
                            <p class="text-dark">We can help you develop and execute a clear and strategic roadmap with priorities that are closely linked to your goals to earn online.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Service End -->


    <!-- About Start -->
    <!-- About Start -->
<div class="container-xxl py-5">
        <div class="container">
            <div class="row g-5">
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s" style="min-height: 400px;">
                    <div class="position-relative h-100">
                        <img class="img-fluid position-absolute w-100 h-100" src="img/about.jpg" alt="" style="object-fit: cover;">
                    </div>
                </div>
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.3s">
                    <h6 class="section-title bg-white text-start text-primary pe-3">About Us</h6>
                    <h1 class="mb-4">Who We Are</h1>
                    <h5 class="mb-4">A startup powerhouse for more earning & profit!</h5>
                    <p class="mb-4">Work smarter, not harder. Income makes managing your freelancing projects and payments simple, fast, and enjoyable. Between smart automation, gorgeous invoices, quick proposals, and dead-simple dashboard, accounting has never been this easy and simple.</p>
                    <div class="row gy-2 gx-4 mb-4">
                        <div class="col-sm-6">
                            <p class="mb-0"><i class="fa fa-arrow-right text-primary me-2"></i>Assignment work</p>
                        </div>
                        <div class="col-sm-6">
                            <p class="mb-0"><i class="fa fa-arrow-right text-primary me-2"></i>Content writing</p>
                        </div>
                        <div class="col-sm-6">
                            <p class="mb-0"><i class="fa fa-arrow-right text-primary me-2"></i>Data Entry</p>
                        </div>
                        <div class="col-sm-6">
                            <p class="mb-0"><i class="fa fa-arrow-right text-primary me-2"></i>Links sharing</p>
                        </div>
                        <div class="col-sm-6">
                            <p class="mb-0"><i class="fa fa-arrow-right text-primary me-2"></i>Online work</p>
                        </div>
                        <div class="col-sm-6">
                            <p class="mb-0"><i class="fa fa-arrow-right text-primary me-2"></i>Content writing</p>
                        </div>
                    </div>
                    <a class="btn btn-primary py-3 px-5 mt-2" href="about.php">VIEW MORE<i class="fa fa-arrow-right ms-3"></i></a>
                </div>
            </div>
        </div>
    </div>
    <!-- About End -->    <!-- About End -->


    <!-- contact banner start -->
    <!-- contact banner start -->
<div class="container-fluid bg-classic d-flex justify-content-center">
        <div class="row d-flex align-items-center shadow-lg w-75 p-5" style="justify-content: space-evenly;">
            <div class="col-md-8">
                <h3 class="text-primary">Get to Start your Career? Register Now and start your Journey</h3>
                <p class="h6">Check out our options and features included</p>
            </div>
            <div class="col-md-3 d-flex justify-content-center mt-lg-0">
                <a class="btn btn-primary btn-lg p-6" href="contact.php">
                    <span class="align-middle">Contact Us<i class="fa fa-arrow-right ms-3"></i></span>
                </a>
            </div>
        </div>
    </div>    
    <!-- contact banner end -->      
    <!-- contact banner end -->
        

    <!-- Footer Start -->
    <!-- Footer Start -->
<div class="container-fluid bg-dark text-light footer pt-3 mt-5 wow fadeIn" data-wow-delay="0.1s">
        <div class="container py-5">
            <div class="row g-5">
                <div class="col-lg-4 col-md-6">
                    <a href="index.php" class="d-flex ">
                        <img src="img/logoo.png" alt="" class="me-3 w-50 h-50">
                    </a>
                    <p>Enhance your freelancing journey with Income – a solution that simplifies project management and payments. Experience the ease of smart automation, beautifully crafted invoices, swift proposals, and a user-friendly dashboard, making accounting both effortless and enjoyable. Work intelligently, not strenuously.</p>
                </div>
                <div class="col-lg-2 col-md-6">
                    <h4 class="text-white mb-3">Quick Link</h4>
                    <a class="btn btn-link" href="index.php">Home</a>
                    <a class="btn btn-link" href="about.php">About Us</a>
                    <a class="btn btn-link" href="team.php">Our Team</a>
                    <a class="btn btn-link" href="services.php">Services</a>
                    <a class="btn btn-link" href="contact.php">Contact Us</a>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h4 class="text-white mb-3">Contact</h4>
                    <p class="mb-2"><i class="fa fa-map-marker-alt me-3"></i>Sector J DHA Phase 6,Lahore</p>
                    <p class="mb-2"><i class="fa fa-envelope me-3"></i>info@bidmarketing.net</p>
                    <p class="mb-2"><i class="fa fa-phone-alt me-3"></i>+923364576140</p>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h4 class="text-white mb-3">Gallery</h4>
                    <div class="row g-2 pt-2">
                        <div class="col-4">
                            <img class="img-fluid bg-light p-1" src="img/course-1.jpg" alt="">
                        </div>
                        <div class="col-4">
                            <img class="img-fluid bg-light p-1" src="img/course-2.jpg" alt="">
                        </div>
                        <div class="col-4">
                            <img class="img-fluid bg-light p-1" src="img/course-3.jpg" alt="">
                        </div>
                        <div class="col-4">
                            <img class="img-fluid bg-light p-1" src="img/course-2.jpg" alt="">
                        </div>
                        <div class="col-4">
                            <img class="img-fluid bg-light p-1" src="img/course-3.jpg" alt="">
                        </div>
                        <div class="col-4">
                            <img class="img-fluid bg-light p-1" src="img/course-1.jpg" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="copyright">
                <div class="row">
                    <div class="col text-center text-md-start mb-3 mb-md-0">
                        &copy; Copyright 2023 | <a class="border-bottom" href="index.php">Bid Marketing</a> | All Right Reserved.
                    </div>
                </div>
            </div>
        </div>
    </div>    
<!-- Footer End -->   
    <!-- Footer End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>